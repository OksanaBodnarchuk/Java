public class Main {
    public static void main(String[] args) {


        /*В предыдущей задаче, для каждого числа, которое делится на 2 выводить надпись «делиться на 2». Для каждого числа, которое делится на 3 выводить надпись «делится на 3» */


        int num1 = 36;
        int num2 = 46;

        //---------------------------------------


        if (num2 > num1){
            while (num1 <= num2) {
                if (num1 % 2 == 0) {
                    System.out.println(num1 + ": делиться на 2");
                }
                if (num1 % 3 == 0) {
                    System.out.println(num1 + ": делиться на 3");
                }
                num1 = num1 + 1;
            }
        }
        if (num1 > num2){
            while (num2 <= num1) {
                if (num2 % 2 == 0) {
                    System.out.println(num2 + ": делиться на 2");
                }
                if (num2 % 3 == 0) {
                    System.out.println(num2 + ": делиться на 3");
                }
                num2 = num2 + 1;
            }}
        
        System.out.println("END");
}}







