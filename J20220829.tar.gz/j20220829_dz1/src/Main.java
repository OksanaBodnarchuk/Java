public class Main {
    public static void main(String[] args) {
         //Необходимо написать программу, которая печатает все целые числа в диапазоне  между num1 и num2 включительно. Учтите, num1 может быть как меньше, так больше или равно  num2.



        int num1 = 46;
        int num2 = 30;

        //---------------------------------------


        if (num2 > num1) {
            while (num1 <= num2) {
                System.out.println(num1);
                num1 = num1 + 1;
            }
        }
            if (num1 > num2) {
                while (num2 <= num1) {
                    System.out.println(num2);
                    num2 = num2 + 1;
                }

        }

        System.out.println("END");
    }
}
